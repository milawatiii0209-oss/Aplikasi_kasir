APLIKASI KASIR MILA
===================

Cara menjalankan:
1. Ekstrak folder ini.
2. Buka index.html di Chrome/Firefox.
3. Pilih produk, masukkan jumlah, masukkan uang pembayaran.
4. Klik "Bayar & Cetak Struk".

Catatan QR:
QR pada CV perlu diarahkan ke alamat online aplikasi setelah aplikasi di-hosting.
Untuk penggunaan tugas sekolah, aplikasi ini bisa di-hosting gratis dengan GitHub Pages.
