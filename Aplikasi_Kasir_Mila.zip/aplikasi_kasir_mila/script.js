const products=[
 {id:1,name:"Nasi Goreng",price:15000},{id:2,name:"Mie Goreng",price:12000},
 {id:3,name:"Seblak",price:10000},{id:4,name:"Es Teh",price:5000},
 {id:5,name:"Kopi",price:7000},{id:6,name:"Air Mineral",price:4000},
 {id:7,name:"Keripik Singkong",price:8000},{id:8,name:"Roti",price:6000}
];
let cart=[];

const rupiah=n=>new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n||0);

function renderProducts(filter=""){
 const list=document.getElementById("productList");
 list.innerHTML=products.filter(p=>p.name.toLowerCase().includes(filter.toLowerCase()))
 .map(p=>`<div class="product"><h3>${p.name}</h3><div class="price">${rupiah(p.price)}</div>
 <button class="btn primary" onclick="addToCart(${p.id})">+ Tambah</button></div>`).join("");
}

function addToCart(id){
 const p=products.find(x=>x.id===id), item=cart.find(x=>x.id===id);
 item?item.qty++:cart.push({...p,qty:1}); renderCart();
}
function changeQty(id,delta){
 const item=cart.find(x=>x.id===id); if(!item)return;
 item.qty+=delta;if(item.qty<=0)cart=cart.filter(x=>x.id!==id);renderCart();
}
function removeItem(id){cart=cart.filter(x=>x.id!==id);renderCart()}

function renderCart(){
 const box=document.getElementById("cartList");
 box.innerHTML=cart.length?cart.map(i=>`<div class="cart-item">
 <div><div class="cart-name">${i.name}</div><small>${rupiah(i.price)} × ${i.qty}</small></div>
 <div class="cart-controls"><button class="small" onclick="changeQty(${i.id},-1)">−</button>
 <span class="qty">${i.qty}</span><button class="small" onclick="changeQty(${i.id},1)">+</button>
 <button class="remove" onclick="removeItem(${i.id})">Hapus</button></div></div>`).join(""):'<p class="empty">Belum ada barang.</p>';
 updateTotals();
}
function updateTotals(){
 const subtotal=cart.reduce((s,i)=>s+i.price*i.qty,0);
 const discount=Math.max(0,Number(document.getElementById("discount").value)||0);
 const total=Math.max(0,subtotal-discount);
 const payment=Math.max(0,Number(document.getElementById("payment").value)||0);
 document.getElementById("subtotal").textContent=rupiah(subtotal);
 document.getElementById("total").textContent=rupiah(total);
 document.getElementById("change").textContent=rupiah(Math.max(0,payment-total));
}
function makeReceipt(){
 if(!cart.length)return alert("Keranjang masih kosong.");
 const subtotal=cart.reduce((s,i)=>s+i.price*i.qty,0);
 const discount=Math.max(0,Number(document.getElementById("discount").value)||0);
 const total=Math.max(0,subtotal-discount);
 const payment=Number(document.getElementById("payment").value)||0;
 if(payment<total)return alert("Uang pembayaran kurang.");
 const now=new Date().toLocaleString("id-ID");
 document.getElementById("receiptContent").innerHTML=`<h2>Kasir Mila</h2><p style="text-align:center">${now}</p><hr>
 ${cart.map(i=>`<div class="receipt-row"><span>${i.name} × ${i.qty}</span><span>${rupiah(i.price*i.qty)}</span></div>`).join("")}
 <hr><div class="receipt-row"><span>Subtotal</span><b>${rupiah(subtotal)}</b></div>
 <div class="receipt-row"><span>Diskon</span><b>${rupiah(discount)}</b></div>
 <div class="receipt-row"><span>Total</span><b>${rupiah(total)}</b></div>
 <div class="receipt-row"><span>Dibayar</span><b>${rupiah(payment)}</b></div>
 <div class="receipt-row"><span>Kembalian</span><b>${rupiah(payment-total)}</b></div>
 <hr><p style="text-align:center">Terima kasih 🙏</p>`;
 document.getElementById("receiptModal").classList.remove("hidden");
}
document.getElementById("search").addEventListener("input",e=>renderProducts(e.target.value));
document.getElementById("discount").addEventListener("input",updateTotals);
document.getElementById("payment").addEventListener("input",updateTotals);
document.getElementById("payBtn").addEventListener("click",makeReceipt);
document.getElementById("closeReceipt").addEventListener("click",()=>document.getElementById("receiptModal").classList.add("hidden"));
document.getElementById("printBtn").addEventListener("click",()=>window.print());
document.getElementById("resetBtn").addEventListener("click",()=>{if(confirm("Reset transaksi?")){cart=[];document.getElementById("discount").value=0;document.getElementById("payment").value="";renderCart()}});
renderProducts();renderCart();
